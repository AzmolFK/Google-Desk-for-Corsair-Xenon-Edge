# Google Desk 0.3.1 — inbox touch controls

The native Primary dropdown could open a popup outside the iCUE-rendered touchscreen surface. It has been replaced with three regular buttons rendered inside the widget:

- **Primary** — primary inbox messages.
- **All inbox** — all inbox categories.
- **No promos** — inbox messages excluding Promotions.

Tap a button directly. Its selected state is highlighted. The Unread filter can be combined with any category. No popup is needed.

## Update the installed widget

1. Quit Google Desk from the tray menu.
2. Copy this update into your existing app folder, replacing application files. **Keep your `data` and optional `.venv` folders.**
3. Open **Google Desk.exe**.
4. Choose **Install paired iCUE widget...** from its tray menu, then import the freshly generated **data/Google-Desk-Paired.icuewidget** into iCUE.
5. Re-add the updated Google Desk widget if iCUE does not refresh the existing instance.

The same saved pairing key and Google authorization are reused. No new permissions or Google scopes are needed.

Browser verification uses sample messages; the final touch behavior still needs checking on the physical XENEON EDGE.
